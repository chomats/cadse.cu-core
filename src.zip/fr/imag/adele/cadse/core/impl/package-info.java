

@PackageInfo(version="1.0.0", requirePackages={})
package fr.imag.adele.cadse.core.impl;

import fr.imag.adele.packageinfo.PackageInfo;
